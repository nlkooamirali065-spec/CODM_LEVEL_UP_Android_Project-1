package com.codm.levelup;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private TextView xpText, levelText;
    private EditText levelInput, xpInput;
    private int xp = 0, level = 1;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("codm_progress", MODE_PRIVATE);
        level = prefs.getInt("level", 1);
        xp = prefs.getInt("xp", 0);

        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 32, 28, 32);
        page.setBackgroundColor(0xFF101827);
        scroll.addView(page);

        TextView title = text("CODM LEVEL UP", 27, 0xFFFFFFFF, true);
        page.addView(title);
        page.addView(text("داشبورد پیگیری پیشرفت", 15, 0xFFB8C5D8, false));

        levelText = text("", 22, 0xFFFFFFFF, true);
        xpText = text("", 18, 0xFF66D9C2, true);
        page.addView(card(levelText));
        page.addView(card(xpText));
        refresh();

        page.addView(section("ثبت پیشرفت"));
        levelInput = new EditText(this);
        levelInput.setSingleLine(true);
        levelInput.setHint("Level فعلی");
        levelInput.setInputType(2);
        levelInput.setText(String.valueOf(level));
        page.addView(levelInput);

        xpInput = new EditText(this);
        xpInput.setSingleLine(true);
        xpInput.setHint("مقدار XP فعلی");
        xpInput.setInputType(2);
        xpInput.setText(String.valueOf(xp));
        page.addView(xpInput);

        Button save = button("ذخیره پیشرفت");
        page.addView(save);
        save.setOnClickListener(v -> {
            try {
                level = Math.max(1, Integer.parseInt(levelInput.getText().toString()));
                xp = Math.max(0, Integer.parseInt(xpInput.getText().toString()));
                prefs.edit().putInt("level", level).putInt("xp", xp).apply();
                refresh();
                Toast.makeText(this, "پیشرفت ذخیره شد", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "مقدار معتبر وارد کن", Toast.LENGTH_SHORT).show();
            }
        });

        page.addView(section("مأموریت‌های شخصی"));
        String[] tasks = {"تکمیل مسابقه روزانه", "بررسی مأموریت‌های رویداد", "ثبت XP پس از بازی", "بررسی پیشرفت هفتگی"};
        for (String task : tasks) {
            CheckBox check = new CheckBox(this);
            check.setText(task);
            check.setTextColor(0xFFFFFFFF);
            check.setButtonTintList(android.content.res.ColorStateList.valueOf(0xFF66D9C2));
            page.addView(check);
        }

        page.addView(section("اجرای بازی"));
        Button launch = button("باز کردن Call of Duty: Mobile");
        page.addView(launch);
        launch.setOnClickListener(v -> {
            Intent intent = getPackageManager().getLaunchIntentForPackage("com.activision.callofduty.shooter");
            if (intent == null) {
                Toast.makeText(this, "بازی نصب نیست یا نسخه آن متفاوت است", Toast.LENGTH_LONG).show();
            } else startActivity(intent);
        });

        page.addView(text("این برنامه فقط برای ثبت و برنامه‌ریزی پیشرفت است و بازی را به‌صورت خودکار انجام نمی‌دهد.", 13, 0xFFB8C5D8, false));
        setContentView(scroll);
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, 10, 0, 10);
        return t;
    }
    private View card(View child) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18, 12, 18, 12);
        box.setBackgroundColor(0xFF1D2A3D);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 16, 0, 0);
        box.addView(child);
        box.setLayoutParams(lp);
        return box;
    }
    private TextView section(String s) {
        TextView t = text(s, 19, 0xFFFFFFFF, true);
        t.setPadding(0, 26, 0, 8);
        return t;
    }
    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        return b;
    }
    private void refresh() {
        if (levelText != null) levelText.setText("Level: " + level);
        if (xpText != null) xpText.setText("XP ثبت‌شده: " + xp);
    }
}
